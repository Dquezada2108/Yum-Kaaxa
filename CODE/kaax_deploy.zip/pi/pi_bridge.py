#!/usr/bin/env python3
"""
KAAX — Plan B: Raspberry Pi as ground station.

  Heltec BASE (USB) <-> this script <-> WebSocket <-> GUI (any browser on the LAN)

Why: Web Serial only works in Chrome/Edge on a laptop. With the Pi you can open
the GUI from a phone/tablet, or keep the base far from the laptop.

Run:   python3 pi_bridge.py [--port /dev/ttyUSB0] [--http 8080]
Open:  http://kaax.local:8080   (GUI served from ../docs — same files as GitHub Pages)
Set Ajustes → Transporte = "Raspberry Pi · WebSocket", URL = ws://kaax.local:8080/ws

Also exposes POST /api/ai → https://ollama.com/api/chat (header X-Ollama-Key)
so the GUI can use Ollama Cloud even if the browser blocks the direct call.
"""
import argparse, asyncio, glob, json, os, sys
import serial            # pyserial
from aiohttp import web, ClientSession

DOCS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "docs")
clients = set()

def find_port(explicit):
    if explicit: return explicit
    for pat in ("/dev/ttyUSB*", "/dev/ttyACM*", "/dev/cu.usbserial*", "/dev/cu.SLAB*"):
        m = glob.glob(pat)
        if m: return m[0]
    sys.exit("No Heltec found. Plug the base station in or pass --port.")

async def serial_reader(app):
    ser = app["ser"]
    loop = asyncio.get_running_loop()
    while True:
        line = await loop.run_in_executor(None, ser.readline)
        if not line: continue
        txt = line.decode(errors="ignore").strip()
        if not txt: continue
        print("<-", txt)
        dead = []
        for ws in clients:
            try: await ws.send_str(txt)
            except Exception: dead.append(ws)
        for ws in dead: clients.discard(ws)

async def ws_handler(request):
    ws = web.WebSocketResponse(heartbeat=20)
    await ws.prepare(request)
    clients.add(ws)
    print("GUI connected", request.remote)
    try:
        async for msg in ws:
            if msg.type == web.WSMsgType.TEXT:
                for l in msg.data.split("\n"):
                    l = l.strip()
                    if l:
                        print("->", l)
                        request.app["ser"].write((l + "\n").encode())
    finally:
        clients.discard(ws)
        print("GUI disconnected")
    return ws

async def ai_proxy(request):
    key = request.headers.get("X-Ollama-Key", "")
    body = await request.read()
    async with ClientSession() as s:
        async with s.post("https://ollama.com/api/chat", data=body,
                          headers={"Authorization": "Bearer " + key, "Content-Type": "application/json"}) as r:
            return web.Response(body=await r.read(), status=r.status, content_type="application/json")

async def index(request):
    return web.FileResponse(os.path.join(DOCS, "index.html"))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port"); ap.add_argument("--baud", type=int, default=115200)
    ap.add_argument("--http", type=int, default=8080)
    a = ap.parse_args()
    port = find_port(a.port)
    app = web.Application()
    app["ser"] = serial.Serial(port, a.baud, timeout=1)
    print("Base station on", port)
    app.add_routes([web.get("/ws", ws_handler), web.post("/api/ai", ai_proxy), web.get("/", index)])
    app.router.add_static("/", DOCS, show_index=False)
    async def start_bg(app): app["task"] = asyncio.create_task(serial_reader(app))
    app.on_startup.append(start_bg)
    web.run_app(app, host="0.0.0.0", port=a.http)

if __name__ == "__main__":
    main()
