#!/usr/bin/env python3
"""
KAAX — Plan C: no Heltec at all. Raspberry Pi 5 on the robot does everything.

  Laptop/phone --WiFi (Pi hotspot)--> this script --> ESCs, servos, GPS

Same line protocol as the LoRa build, so the GUI does not change:
  in : CMD,<id>,R,L · NET,<id>,0|1 · STOP,<id> · PING,<id>
  out: KAAX,<id>,lat,lon,b1,b2,fix,spd_kmh,hdg

WIRING (BCM numbering, Pi 5 — same as the earlier Pi build)
  GPIO18  ESC right     GPIO19  ESC left
  GPIO12  Servo net R   GPIO13  Servo net L
  GPIO14/15 (UART0, /dev/serial0)  GPS TX->15, GPS RX<-14   (enable UART in raspi-config)
  I2C SDA/SCL (GPIO2/3)  optional ADS1115 for the two battery dividers (A0,A1)
  Common ground everywhere. Pi powered from a 5 V UBEC, never from the ESC BEC.

Run:   python3 pi_robot.py --id 01
Open:  http://kaax.local:8080   → Ajustes → WebSocket ws://kaax.local:8080/ws
"""
import argparse, asyncio, os, time, glob
from aiohttp import web, ClientSession

DOCS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "docs")
PIN_ESC_R, PIN_ESC_L, PIN_SRV_R, PIN_SRV_L = 18, 19, 12, 13
NEUTRAL, MIN_US, MAX_US = 1500, 1100, 1900
NET_UP, NET_DOWN = 1100, 1900          # servo pulse widths (µs)
FAILSAFE_S, TELEMETRY_S = 1.5, 1.0
BATT_RATIO = 6.0                       # 100k/20k divider on ADS1115 inputs

# ---- hardware (all optional so the script still runs on a bare Pi) -------
try:
    import lgpio
    H = lgpio.gpiochip_open(4)         # Pi 5 header is gpiochip 4
    for p in (PIN_ESC_R, PIN_ESC_L, PIN_SRV_R, PIN_SRV_L): lgpio.gpio_claim_output(H, p)
    def pulse(pin, us): lgpio.tx_servo(H, pin, int(max(500, min(2500, us))), 50)
except Exception as e:
    print("lgpio unavailable, motors disabled:", e)
    def pulse(pin, us): pass

try:
    import serial, pynmea2
    gps_ser = serial.Serial("/dev/serial0", 9600, timeout=0)
except Exception as e:
    print("GPS unavailable:", e); gps_ser = None

try:
    from smbus2 import SMBus
    bus = SMBus(1)
    def read_ads(ch):                  # ADS1115, single-shot, ±4.096 V, addr 0x48
        cfg = 0x8383 | (0x4000 + ch * 0x1000) | 0x0200
        bus.write_i2c_block_data(0x48, 1, [cfg >> 8, cfg & 0xFF]); time.sleep(0.01)
        d = bus.read_i2c_block_data(0x48, 0, 2); raw = (d[0] << 8 | d[1]);
        raw = raw - 65536 if raw > 32767 else raw
        return raw * 4.096 / 32768 * BATT_RATIO
except Exception as e:
    print("ADS1115 unavailable, battery = 0:", e)
    def read_ads(ch): return 0.0

state = dict(R=NEUTRAL, L=NEUTRAL, net=0, last_cmd=0.0, lat=0.0, lon=0.0, fix=0, spd=0.0, hdg=0.0)
clients = set()

def apply():
    pulse(PIN_ESC_R, state["R"]); pulse(PIN_ESC_L, state["L"])
    pulse(PIN_SRV_R, NET_DOWN if state["net"] else NET_UP)
    pulse(PIN_SRV_L, NET_UP if state["net"] else NET_DOWN)

def handle(line, rid):
    p = line.split(",")
    if len(p) < 2 or p[1] not in (rid, "00"): return
    if p[0] == "CMD" and len(p) >= 4:
        state["R"] = max(MIN_US, min(MAX_US, int(p[2]))); state["L"] = max(MIN_US, min(MAX_US, int(p[3])))
        state["last_cmd"] = time.time(); apply()
    elif p[0] == "STOP": state["R"] = state["L"] = NEUTRAL; apply()
    elif p[0] == "NET" and len(p) >= 3: state["net"] = int(p[2]); apply()
    elif p[0] == "PING": return "ping"

def poll_gps():
    if not gps_ser: return
    try:
        for raw in gps_ser.read(2048).decode(errors="ignore").splitlines():
            if raw.startswith(("$GPRMC", "$GNRMC")):
                m = pynmea2.parse(raw)
                state["fix"] = 1 if m.status == "A" else 0
                if state["fix"]:
                    state["lat"], state["lon"] = m.latitude, m.longitude
                    state["spd"] = (m.spd_over_grnd or 0) * 1.852; state["hdg"] = m.true_course or 0
    except Exception: pass

async def telemetry(app):
    rid = app["id"]
    while True:
        await asyncio.sleep(TELEMETRY_S)
        poll_gps()
        if (state["R"] != NEUTRAL or state["L"] != NEUTRAL) and time.time() - state["last_cmd"] > FAILSAFE_S:
            state["R"] = state["L"] = NEUTRAL; apply(); print("failsafe stop")
        msg = f"KAAX,{rid},{state['lat']:.6f},{state['lon']:.6f},{read_ads(0):.2f},{read_ads(1):.2f},{state['fix']},{state['spd']:.2f},{state['hdg']:.0f}"
        for ws in list(clients):
            try: await ws.send_str(msg)
            except Exception: clients.discard(ws)

async def ws_handler(request):
    ws = web.WebSocketResponse(heartbeat=20); await ws.prepare(request); clients.add(ws)
    try:
        async for m in ws:
            if m.type == web.WSMsgType.TEXT:
                for l in m.data.split("\n"):
                    if l.strip(): handle(l.strip(), request.app["id"])
    finally: clients.discard(ws)
    return ws

async def ai_proxy(request):
    key = request.headers.get("X-Ollama-Key", ""); body = await request.read()
    async with ClientSession() as s:
        async with s.post("https://ollama.com/api/chat", data=body, headers={"Authorization": "Bearer " + key, "Content-Type": "application/json"}) as r:
            return web.Response(body=await r.read(), status=r.status, content_type="application/json")

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--id", default="01"); ap.add_argument("--http", type=int, default=8080)
    a = ap.parse_args()
    apply(); time.sleep(3)                      # arm ESCs at neutral
    app = web.Application(); app["id"] = a.id
    app.add_routes([web.get("/ws", ws_handler), web.post("/api/ai", ai_proxy),
                    web.get("/", lambda r: web.FileResponse(os.path.join(DOCS, "index.html")))])
    app.router.add_static("/", DOCS)
    async def start_bg(app): app["task"] = asyncio.create_task(telemetry(app))
    app.on_startup.append(start_bg)
    print(f"KAAX robot {a.id} ready on port {a.http}")
    web.run_app(app, host="0.0.0.0", port=a.http)

if __name__ == "__main__":
    main()
